# High-Low Card Game for Ethereum Network #
## Ethereum smart contract for the game High-Low, written in Solidity. ##

**Rules:**

* Contract will announce a card.
* All players will place a bet with an amount and a variable to signify their bet (High or Low). Each player is unable to view bets placed by other players.
* At a set time, the contract calculates the next random card from the unused deck, and adds the current card to the burn deck.
* Contract will send 2x bet amount to each winner.
* When only 10 cards are left, the burn deck will be mixed with the unused deck to start fresh.

- - - -

**Instructions To Play:**

Set gas value to be : 700,0000 & compiler : 0.5.0

* Click on StateOfGame for the current step 
* Set the number of players during 1st step with setNumOfPlayers
* Then the game transits to adding players state
* For adding players, add names using "setPlayer" function
* Then the game transits to bets placing state
* Each player can place his bet when his turns come "according to showCurrentPlayer", with either "high" or "low" & amount <= his current value
* current value can be checked by "showPlayerValue" by specifing player's name
* Then, after all are done with bets.. game transits into "Done" stage
* Click on "calculateRewards" for showing up the card & distributing rewards
* Finally, game continues to take bets until 10 cards are left & then the burned cards gets added again & game is reinitialized.
* "showPreviousCard" can be used to check what was the previous card
* "exitGame" can be used to reinitialize everything and end the current game

- - - -

Assignment for Distributing Trust and Blockchains - Monsoon 2019, IIIT Hyderabad

Authors:
Nikhil Vemuri (201564142), 
Rishabh Singhal (20171213)
